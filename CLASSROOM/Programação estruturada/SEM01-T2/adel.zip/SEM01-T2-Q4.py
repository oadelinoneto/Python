x = float(input())
print(9*x-4*x+10)