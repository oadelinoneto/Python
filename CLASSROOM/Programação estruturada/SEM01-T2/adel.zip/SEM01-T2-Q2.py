nome = input("").strip()
sobrenome = input("").strip()
print(f"{nome} {sobrenome}")