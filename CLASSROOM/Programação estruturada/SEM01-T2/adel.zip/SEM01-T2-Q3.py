numero1 = float(input())
numero2 = float(input())
print(numero1 + numero2)
print(numero1 * numero2)