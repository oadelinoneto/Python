hype = int(input())
print("G"+"o"*hype+"l!")